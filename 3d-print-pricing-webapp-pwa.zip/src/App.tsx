import React, { useEffect, useMemo, useState } from "react";

/**
 * 3D Print Pricing Calculator – Multi‑Platform (Client‑side)
 * Mobile‑friendly, dark‑mode ready. All client‑side; deploy on Vercel.
 */

// -------------------------- Utilities --------------------------
const money = (n: number | null | undefined) => (isFinite(n as number) ? (n as number) : 0);

const fmt = (n: number, digits: number = 2) =>
  new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(money(n));

const pct = (n: number, digits: number = 1) => `${((money(n) || 0) * 100).toFixed(digits)}%`;
const clamp = (n: number, min = 0, max = Number.POSITIVE_INFINITY) => Math.min(Math.max(n, min), max);
const num = (v: any) => {
  const n = typeof v === "string" ? Number(v) : v;
  return isFinite(n) ? n : 0;
};

// Persistent state hook
function useLocal<T>(key: string, init: T) {
  const [state, setState] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : init;
    } catch {
      return init;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch {}
  }, [key, state]);
  return [state, setState] as const;
}

// -------------------------- Presets --------------------------
type FeeBase = "TOTAL" | "ITEM";
type PlatformKey = "Etsy" | "Shopify" | "eBay" | "Mercari";

interface PlatformPreset {
  feeBase: FeeBase;
  transPct: number;
  procPct: number;
  procFixed: number;
  listPerItem: number;
  extraPct: number;
  extraFixed: number;
  monthlyAlloc: number;
}

const DEFAULT_PRESETS: Record<PlatformKey, PlatformPreset> = {
  Etsy: { feeBase: "TOTAL", transPct: 0.065, procPct: 0.03, procFixed: 0.25, listPerItem: 0.20, extraPct: 0.00, extraFixed: 0.00, monthlyAlloc: 0.00 },
  Shopify: { feeBase: "TOTAL", transPct: 0.00, procPct: 0.029, procFixed: 0.30, listPerItem: 0.00, extraPct: 0.00, extraFixed: 0.00, monthlyAlloc: 0.00 },
  eBay: { feeBase: "TOTAL", transPct: 0.1325, procPct: 0.00, procFixed: 0.30, listPerItem: 0.00, extraPct: 0.00, extraFixed: 0.00, monthlyAlloc: 0.00 },
  Mercari: { feeBase: "TOTAL", transPct: 0.10, procPct: 0.029, procFixed: 0.50, listPerItem: 0.00, extraPct: 0.00, extraFixed: 0.00, monthlyAlloc: 0.00 },
};

// -------------------------- Types --------------------------
interface CostBuilderInputs {
  filamentPricePerKg: number;
  gramsUsed: number;
  watts: number;
  hours: number;
  kwhRate: number;
  depPerHour: number;
  consPerHour: number;
  laborHours: number;
  laborRate: number;
  overheadRate: number;
  itemsPerRun: number;
}

interface OrderInputs {
  platform: PlatformKey;
  quantity: number;
  itemPrice: number;
  shippingCharged: number;
  labelCost: number;
  useCostBuilder: boolean;
  manualUnitCost: number;
}

// -------------------------- Calculations --------------------------
function calcCostBuilder(i: CostBuilderInputs) {
  const material = (i.filamentPricePerKg / 1000) * i.gramsUsed;
  const electricity = (i.watts / 1000) * i.hours * i.kwhRate;
  const depreciation = i.depPerHour * i.hours;
  const consumables = i.consPerHour * i.hours;
  const labor = i.laborHours * i.laborRate;
  const subtotal = material + electricity + depreciation + consumables + labor;
  const overhead = subtotal * i.overheadRate;
  const totalRun = subtotal + overhead;
  const unitCost = i.itemsPerRun > 0 ? totalRun / i.itemsPerRun : 0;
  return { material, electricity, depreciation, consumables, labor, subtotal, overhead, totalRun, unitCost };
}

function calcOrder(o: OrderInputs, presets: Record<PlatformKey, PlatformPreset>, perUnitCost: number) {
  const P = presets[o.platform];
  const Q = clamp(o.quantity, 1, 1e6);
  const S = money(o.shippingCharged);
  const label = money(o.labelCost);
  const c = money(perUnitCost);

  const itemsRevenue = Q * money(o.itemPrice);
  const revenue = itemsRevenue + S;

  const base = P.feeBase === "ITEM" ? itemsRevenue : revenue;

  const transFee = base * P.transPct;
  const procFee = revenue * P.procPct + P.procFixed;
  const listingFees = P.listPerItem * Q;
  const extraFees = revenue * P.extraPct + P.extraFixed + P.monthlyAlloc;
  const cogs = Q * c;

  const net = revenue - (transFee + procFee + listingFees + extraFees + label + cogs);
  const netPerItem = net / Q;
  const margin = revenue > 0 ? net / revenue : 0;

  return { revenue, itemsRevenue, base, transFee, procFee, listingFees, extraFees, label, cogs, net, netPerItem, margin };
}

function requiredPriceEach(targetNet: number, Q: number, S: number, label: number, c: number, P: PlatformPreset) {
  const t = P.transPct, pr = P.procPct, ex = P.extraPct;
  const pf = P.procFixed, list = P.listPerItem, extraf = P.extraFixed, monthly = P.monthlyAlloc;
  const denom = (1 - t - pr - ex);
  if (denom <= 0) return NaN;

  if (P.feeBase === "TOTAL") {
    return (targetNet + pf + list * Q + extraf + monthly + label + Q * c - S * denom) / (Q * denom);
  } else {
    return (targetNet + pf + list * Q + extraf + monthly + label + Q * c - S * (1 - pr - ex)) / (Q * denom);
  }
}

// -------------------------- UI --------------------------
const Section: React.FC<{ title: string; subtitle?: string; right?: React.ReactNode; }>
  = ({ title, subtitle, right, children }) => (
  <div className="rounded-2xl shadow-sm bg-white/90 dark:bg-zinc-900 p-4 md:p-6 border border-zinc-200/60 dark:border-zinc-800 overflow-hidden">
    <div className="flex items-center justify-between gap-3 mb-3">
      <div className="min-w-0">
        <h2 className="text-lg md:text-xl font-semibold tracking-tight">{title}</h2>
        {subtitle && <p className="text-xs md:text-sm text-zinc-500 mt-0.5 break-words">{subtitle}</p>}
      </div>
      {right}
    </div>
    {children}
  </div>
);

const Row: React.FC<{ label: string; children?: React.ReactNode; hint?: string; }>
  = ({ label, children, hint }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 items-center py-2 border-b border-zinc-100 dark:border-zinc-800 last:border-b-0 gap-2">
    <div className="text-sm text-zinc-600 dark:text-zinc-300 break-words">
      {label}{hint && <span className="text-zinc-400"> — {hint}</span>}
    </div>
    <div className="mt-1 md:mt-0 min-w-0">{children}</div>
  </div>
);

const NumInput: React.FC<{
  value: number; onChange: (n: number) => void; min?: number; step?: number; prefix?: string; suffix?: string; placeholder?: string;
}> = ({ value, onChange, min = 0, step = 0.01, prefix, suffix, placeholder }) => (
  <div className="flex items-center gap-2 min-w-0">
    {prefix && <span className="text-zinc-500 shrink-0">{prefix}</span>}
    <input
      inputMode="decimal"
      className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3 py-2 text-sm min-w-0"
      value={isFinite(value) ? value : 0}
      onChange={(e) => onChange(clamp(num(e.target.value), min))}
      type="number"
      step={step}
      placeholder={placeholder}
    />
    {suffix && <span className="text-zinc-500 shrink-0">{suffix}</span>}
  </div>
);

const Switch: React.FC<{ checked: boolean; onChange: (v: boolean) => void; }>
  = ({ checked, onChange }) => (
  <button
    onClick={() => onChange(!checked)}
    className={`inline-flex h-6 w-11 items-center rounded-full transition ${checked ? 'bg-emerald-600' : 'bg-zinc-300 dark:bg-zinc-700'}`}
    aria-pressed={checked}
  >
    <span className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition ${checked ? 'translate-x-6' : 'translate-x-1'}`} />
  </button>
);

const Tag: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-xs text-zinc-600 dark:text-zinc-300">{children}</span>
);

export default function App() {
  // Cost Builder state
  const [costIn, setCostIn] = useLocal<CostBuilderInputs>("costBuilder", {
    filamentPricePerKg: 14.99,
    gramsUsed: 818,
    watts: 100,
    hours: 31.6,
    kwhRate: 0.1307,
    depPerHour: 0.233,
    consPerHour: 0.15,
    laborHours: 0.5,
    laborRate: 25,
    overheadRate: 0.10,
    itemsPerRun: 12,
  });
  const cost = useMemo(() => calcCostBuilder(costIn), [costIn]);

  // Platform presets
  const [presets, setPresets] = useLocal<Record<PlatformKey, PlatformPreset>>("platformPresets", DEFAULT_PRESETS);

  // Order inputs
  const [orderIn, setOrderIn] = useLocal<OrderInputs>("orderInputs", {
    platform: "Etsy",
    quantity: 1,
    itemPrice: 6.00,
    shippingCharged: 3.99,
    labelCost: 4.00,
    useCostBuilder: true,
    manualUnitCost: 3.42,
  });

  const usedUnitCost = orderIn.useCostBuilder ? cost.unitCost : orderIn.manualUnitCost;
  const result = useMemo(() => calcOrder(orderIn, presets, usedUnitCost), [orderIn, presets, usedUnitCost]);

  // Solver
  const [targetNet, setTargetNet] = useLocal<number>("targetNet", 5);
  const requiredPrice = useMemo(() => requiredPriceEach(
    targetNet,
    clamp(orderIn.quantity, 1),
    money(orderIn.shippingCharged),
    money(orderIn.labelCost),
    money(usedUnitCost),
    presets[orderIn.platform]
  ), [targetNet, orderIn, presets, usedUnitCost]);

  // Platform comparison
  const platforms: PlatformKey[] = ["Etsy", "Shopify", "eBay", "Mercari"];
  const comparison = useMemo(() => platforms.map(p => {
    const tmp = { ...orderIn, platform: p as PlatformKey } as OrderInputs;
    const r = calcOrder(tmp, presets, usedUnitCost);
    return { platform: p, net: r.net, netPerItem: r.netPerItem, margin: r.margin };
  }), [orderIn, presets, usedUnitCost]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-50 to-white dark:from-zinc-950 dark:to-zinc-900 text-zinc-900 dark:text-zinc-100">
      <div className="mx-auto max-w-6xl px-4 py-6 md:py-10">
        <header className="mb-6 md:mb-8 flex flex-col md:flex-row md:items-end md:justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight">3D Print Pricing Calculator</h1>
            <p className="text-sm text-zinc-500">Cost Builder • Multi‑Platform Fees • Profit & Price Solver • Comparison</p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <Tag>Local save</Tag>
            <Tag>Mobile‑friendly</Tag>
            <Tag>All client‑side</Tag>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
          {/* Cost Builder */}
          <Section title="Cost Builder (per run)" subtitle="Computes per‑unit production cost from your print run">
            <div className="space-y-2">
              <Row label="Filament price per kg"><NumInput value={costIn.filamentPricePerKg} onChange={(v)=>setCostIn({...costIn, filamentPricePerKg: v})} prefix="$" /></Row>
              <Row label="Filament used this run"><NumInput value={costIn.gramsUsed} onChange={(v)=>setCostIn({...costIn, gramsUsed: v})} suffix="g" /></Row>
              <Row label="Printer average power draw"><NumInput value={costIn.watts} onChange={(v)=>setCostIn({...costIn, watts: v})} suffix="W" /></Row>
              <Row label="Print time this run"><NumInput value={costIn.hours} onChange={(v)=>setCostIn({...costIn, hours: v})} suffix="h" /></Row>
              <Row label="Electricity rate"><NumInput value={costIn.kwhRate} onChange={(v)=>setCostIn({...costIn, kwhRate: v})} prefix="$" suffix="/kWh" /></Row>
              <Row label="Printer depreciation per hour"><NumInput value={costIn.depPerHour} onChange={(v)=>setCostIn({...costIn, depPerHour: v})} prefix="$" suffix="/hr" /></Row>
              <Row label="Consumables/maintenance per hour"><NumInput value={costIn.consPerHour} onChange={(v)=>setCostIn({...costIn, consPerHour: v})} prefix="$" suffix="/hr" /></Row>
              <Row label="Labor (hands‑on) time"><NumInput value={costIn.laborHours} onChange={(v)=>setCostIn({...costIn, laborHours: v})} suffix="hr" /></Row>
              <Row label="Labor rate"><NumInput value={costIn.laborRate} onChange={(v)=>setCostIn({...costIn, laborRate: v})} prefix="$" suffix="/hr" /></Row>
              <Row label="Overhead rate on subtotal"><NumInput value={costIn.overheadRate} onChange={(v)=>setCostIn({...costIn, overheadRate: v})} step={0.01} suffix=" (0.10 = 10%)" /></Row>
              <Row label="Items produced in this run"><NumInput value={costIn.itemsPerRun} onChange={(v)=>setCostIn({...costIn, itemsPerRun: v})} step={1} /></Row>
            </div>

            <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Material</div><div className="font-semibold">{fmt(cost.material)}</div></div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Electricity</div><div className="font-semibold">{fmt(cost.electricity)}</div></div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Depreciation</div><div className="font-semibold">{fmt(cost.depreciation)}</div></div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Consumables</div><div className="font-semibold">{fmt(cost.consumables)}</div></div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Labor</div><div className="font-semibold">{fmt(cost.labor)}</div></div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3 col-span-2 md:col-span-1"><div className="text-zinc-500">Overhead</div><div className="font-semibold">{fmt(cost.overhead)}</div></div>
            </div>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Total run cost</div><div className="text-lg font-bold">{fmt(cost.totalRun)}</div></div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Per‑unit production cost</div><div className="text-lg font-bold">{fmt(cost.unitCost)}</div></div>
            </div>
          </Section>

          {/* Platform & Order Calculator */}
          <Section title="Order Calculator" subtitle="Platform fees + shipping + unit cost → profit & margin">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Row label="Platform">
                  <select
                    className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3 py-2 text-sm"
                    value={orderIn.platform}
                    onChange={(e)=>setOrderIn({...orderIn, platform: e.target.value as PlatformKey})}
                  >
                    {(["Etsy","Shopify","eBay","Mercari"] as PlatformKey[]).map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </Row>
                <Row label="Quantity in order"><NumInput value={orderIn.quantity} onChange={(v)=>setOrderIn({...orderIn, quantity: Math.max(1, Math.round(v))})} step={1} /></Row>
                <Row label="Item price (each)"><NumInput value={orderIn.itemPrice} onChange={(v)=>setOrderIn({...orderIn, itemPrice: v})} prefix="$" /></Row>
                <Row label="Shipping charged to buyer (order)"><NumInput value={orderIn.shippingCharged} onChange={(v)=>setOrderIn({...orderIn, shippingCharged: v})} prefix="$" /></Row>
                <Row label="Shipping label cost (order)"><NumInput value={orderIn.labelCost} onChange={(v)=>setOrderIn({...orderIn, labelCost: v})} prefix="$" /></Row>
              </div>

              <div className="space-y-3">
                <Row label="Use Cost Builder per‑unit cost?">
                  <div className="flex items-center gap-3 min-w-0">
                    <Switch checked={orderIn.useCostBuilder} onChange={(v)=>setOrderIn({...orderIn, useCostBuilder: v})} />
                    <span className="text-sm text-zinc-500">{orderIn.useCostBuilder ? fmt(cost.unitCost) : fmt(orderIn.manualUnitCost)}</span>
                  </div>
                </Row>
                {!orderIn.useCostBuilder && (
                  <Row label="Manual per‑unit cost override"><NumInput value={orderIn.manualUnitCost} onChange={(v)=>setOrderIn({...orderIn, manualUnitCost: v})} prefix="$" /></Row>
                )}

                {/* Fees card */}
                <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3">
                  <div className="text-xs uppercase tracking-wide text-zinc-500 mb-2">{orderIn.platform} fees</div>
                  {(() => {
                    const p = presets[orderIn.platform];
                    return (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 text-sm">
                        <Row label="Fee base">
                          <select
                            className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 px-3 py-2 text-sm"
                            value={p.feeBase}
                            onChange={(e)=>setPresets({...presets, [orderIn.platform]: { ...p, feeBase: e.target.value as FeeBase }})}
                          >
                            <option value="TOTAL">TOTAL (item + shipping)</option>
                            <option value="ITEM">ITEM (items only)</option>
                          </select>
                        </Row>
                        <Row label="Transaction %"><NumInput value={p.transPct} onChange={(v)=>setPresets({...presets, [orderIn.platform]: { ...p, transPct: v }})} step={0.001} suffix=" (0.065 = 6.5%)" /></Row>
                        <Row label="Processing %"><NumInput value={p.procPct} onChange={(v)=>setPresets({...presets, [orderIn.platform]: { ...p, procPct: v }})} step={0.001} suffix=" (0.029 = 2.9%)" /></Row>
                        <Row label="Processing fixed $"><NumInput value={p.procFixed} onChange={(v)=>setPresets({...presets, [orderIn.platform]: { ...p, procFixed: v }})} prefix="$" /></Row>
                        <Row label="Listing fee $/item"><NumInput value={p.listPerItem} onChange={(v)=>setPresets({...presets, [orderIn.platform]: { ...p, listPerItem: v }})} prefix="$" /></Row>
                        <Row label="Extra % (ads/etc)"><NumInput value={p.extraPct} onChange={(v)=>setPresets({...presets, [orderIn.platform]: { ...p, extraPct: v }})} step={0.001} suffix=" (fraction)" /></Row>
                        <Row label="Extra fixed $"><NumInput value={p.extraFixed} onChange={(v)=>setPresets({...presets, [orderIn.platform]: { ...p, extraFixed: v }})} prefix="$" /></Row>
                        <Row label="Monthly alloc $/order"><NumInput value={p.monthlyAlloc} onChange={(v)=>setPresets({...presets, [orderIn.platform]: { ...p, monthlyAlloc: v }})} prefix="$" /></Row>
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>

            {/* Results */}
            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Order revenue</div><div className="text-lg font-bold">{fmt(result.revenue)}</div></div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Net profit (order)</div><div className="text-lg font-bold">{fmt(result.net)}</div></div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3"><div className="text-zinc-500">Net per item</div><div className="text-lg font-bold">{fmt(result.netPerItem)}</div></div>
            </div>

            <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs md:text-sm">
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3">
                <div className="text-zinc-500 mb-1">Fee breakdown</div>
                <ul className="space-y-1">
                  <li>Transaction fees: <b>{fmt(result.transFee)}</b></li>
                  <li>Processing fees: <b>{fmt(result.procFee)}</b></li>
                  <li>Listing fees: <b>{fmt(result.listingFees)}</b></li>
                  <li>Extra fees: <b>{fmt(result.extraFees)}</b></li>
                </ul>
              </div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3">
                <div className="text-zinc-500 mb-1">Shipping & COGS</div>
                <ul className="space-y-1">
                  <li>Shipping label: <b>{fmt(result.label)}</b></li>
                  <li>Production cost: <b>{fmt(result.cogs)}</b></li>
                </ul>
              </div>
              <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3">
                <div className="text-zinc-500 mb-1">Margin</div>
                <div className="text-lg font-semibold">{pct(result.margin)}</div>
              </div>
            </div>

            {/* Solver */}
            <div className="mt-4 rounded-xl border border-zinc-200 dark:border-zinc-800 p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm font-medium">Target profit solver</div>
                <Tag>platform‑aware</Tag>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
                <div>
                  <div className="text-xs text-zinc-500 mb-1">Target net profit per ORDER</div>
                  <NumInput value={targetNet} onChange={setTargetNet} prefix="$" />
                </div>
                <div>
                  <div className="text-xs text-zinc-500 mb-1">Required item price (each)</div>
                  <div className="text-lg font-bold">{isFinite(requiredPrice) ? fmt(requiredPrice) : "—"}</div>
                </div>
                <div className="text-xs text-zinc-500">Tip: use this to back‑solve your listing price for a bundle or free‑shipping offer.</div>
              </div>
            </div>
          </Section>
        </div>

        {/* Comparison */}
        <div className="mt-6">
          <Section title="Platform Comparison" subtitle="Same inputs + unit cost; different fee rules">
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="text-left text-zinc-500 border-b border-zinc-200 dark:border-zinc-800">
                    <th className="py-2 pr-4">Platform</th>
                    <th className="py-2 pr-4">Net / order</th>
                    <th className="py-2 pr-4">Net / item</th>
                    <th className="py-2 pr-4">Margin</th>
                  </tr>
                </thead>
                <tbody>
                  {comparison.map((r) => (
                    <tr key={r.platform} className="border-b border-zinc-100 dark:border-zinc-800 last:border-b-0">
                      <td className="py-2 pr-4">{r.platform}</td>
                      <td className="py-2 pr-4 font-medium">{fmt(r.net)}</td>
                      <td className="py-2 pr-4">{fmt(r.netPerItem)}</td>
                      <td className="py-2 pr-4">{pct(r.margin)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-zinc-500 mt-2">Edit fee presets in the Order Calculator → Fees card for the currently selected platform. Values auto‑save to your device.</p>
          </Section>
        </div>

        {/* Footer */}
        <div className="mt-6 text-xs text-zinc-500 flex flex-col md:flex-row gap-2 md:items-center md:justify-between">
          <div>Built for Bambu P1S + PLA workflows. Use your real label discounts & fee schedules for best accuracy.</div>
          <div className="opacity-70">v1.1 – client‑side only • works offline once loaded</div>
        </div>
      </div>
    </div>
  );
}
